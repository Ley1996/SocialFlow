# Just Lhey Things — Strategy Cockpit

A daily social-media strategy dashboard for **Just Lhey Things** (Carla "Lhey" Labado — Filipina freediver & adventurer). It tracks content, weekly growth, per-video performance, and runs a "War Room" of strategy teams.

It's a single-page web app. No build step, no server, no login. Your data is saved **in your own browser** (localStorage), so it stays on your device.

---

## What's inside

| File | What it is |
|------|-----------|
| `index.html` | The whole app. Open it and it runs. |
| `manifest.json` | Lets you "install" it to your phone/desktop like an app. |
| `icon.svg` | The app icon. |
| `README.md` | This file. |

---

## Put it online with GitHub Pages (free)

You'll get a live link like `https://YOURNAME.github.io/just-lhey-things/` that works on any device.

### Step 1 — Make a GitHub account
If you don't have one, sign up free at https://github.com.

### Step 2 — Create a new repository
1. Click the **+** in the top-right of GitHub → **New repository**.
2. Repository name: `just-lhey-things`
3. Set it to **Public** (Pages needs public on the free plan).
4. Do **not** add a README (this folder already has one).
5. Click **Create repository**.

### Step 3 — Upload these files
1. On the new empty repo page, click **uploading an existing file**.
2. Drag in **all four files** from this folder: `index.html`, `manifest.json`, `icon.svg`, `README.md`.
3. Scroll down, click **Commit changes**.

### Step 4 — Turn on GitHub Pages
1. In your repo, click **Settings** (top menu).
2. Left sidebar → **Pages**.
3. Under **Build and deployment** → **Source**, choose **Deploy from a branch**.
4. Branch: pick **main**, folder **/ (root)**. Click **Save**.
5. Wait about 1 minute. Refresh the page — a green box appears with your live link:
   `https://YOURNAME.github.io/just-lhey-things/`

That link is your app. Open it on your phone, bookmark it, share it.

### Step 5 (optional) — Install it like a phone app
- **iPhone (Safari):** open the link → Share button → **Add to Home Screen**.
- **Android (Chrome):** open the link → menu (⋮) → **Install app** / **Add to Home Screen**.
- **Desktop (Chrome/Edge):** open the link → an **install icon** appears in the address bar.

It then opens full-screen like a real app, with the **L** icon.

---

## Updating the app later
When you want changes, edit `index.html` (or ask Claude for a new version), then in your repo:
**Add file → Upload files → drag the new `index.html` → Commit changes.**
Pages re-publishes automatically in about a minute.

---

## Important: where your data lives
Your entries (posts, growth weeks, team notes, logs) are saved in **the browser you use**, on **that device**. They are **not** synced to the cloud or to GitHub.

- Use the **same browser on the same device** to keep your history.
- Clearing your browser data / "site data" will erase it.
- It will **not** carry over between your phone and your laptop automatically.

If you later want cloud sync across devices (so your phone and laptop share data), that needs a small backend — ask Claude and it can walk you through adding one (e.g. a free Supabase or Firebase database).

---

## Run it locally first (optional)
Just double-click `index.html` — it opens in your browser and works immediately. Good for testing before you deploy.

---

*Built as a living cockpit: feed it your real numbers, and the charts, pillars, and teams update around them.*
